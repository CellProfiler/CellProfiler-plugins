Invoke-WebRequest https://api.adoptopenjdk.net/v3/installer/latest/11/ga/windows/x64/jdk/hotspot/normal/adoptopenjdk?project=jdk -OutFile .\openjdk11.msi
(Start-Process "msiexec.exe" -ArgumentList "/i openjdk11.msi INSTALLDIR=""C:\Program Files\Java-jdk-11\"" /quiet /passive" -NoNewWindow -Wait -PassThru).ExitCode
Remove-Item .\openjdk11.msi
